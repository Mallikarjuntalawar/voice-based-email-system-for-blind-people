from django.urls import path
from . import views

app_name = 'homepage'

urlpatterns = [
    path('', views.login_view, name="login"),
    path('', views.compose_view, name="compose"),
    path('', views.inbox_view, name="inbox"),
    path('', views.sent_view, name="sent"),
    path('', views.trash_view, name="trash"),
    path('', views.options_view, name="options")
   
]
